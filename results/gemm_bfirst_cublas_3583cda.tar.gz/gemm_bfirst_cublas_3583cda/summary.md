# BF16 GEMM ours vs cuBLAS remeasurement

Square row-major `C=A*B`, BF16 A/B, FP32 accumulation/output.
Each cell is mean +/- sample SD across four independent processes;
each process uses one warmup and five timed launches. The two methods
occupy the first and second positions exactly twice per cell.

| size | input | ours (static `8x16`) | cuBLAS | ours/cuBLAS |
|---:|---|---:|---:|---:|
| 8K | `[0,1)` | 1763.599 +/- 1.260 | 1822.687 +/- 3.414 | 96.758% |
| 8K | `[-8,8)` | 1592.419 +/- 3.685 | 1619.840 +/- 6.199 | 98.307% |
| 16K | `[0,1)` | 1854.043 +/- 1.457 | 1924.352 +/- 1.688 | 96.346% |
| 16K | `[-8,8)` | 1648.123 +/- 3.490 | 1708.077 +/- 2.013 | 96.490% |
| 32K | `[0,1)` | 1666.094 +/- 12.326 | 1698.081 +/- 10.980 | 98.116% |
| 32K | `[-8,8)` | 1435.286 +/- 15.128 | 1466.391 +/- 1.892 | 97.879% |
